<template>
  <StudioAgentPage kind="qa" title="财会与土地评估专用问答" description="基于工作室知识库回答土地评估、财会报表和制度问题。" />
</template>
<script setup lang="ts">
import StudioAgentPage from '@/components/studio/StudioAgentPage.vue'
</script>
