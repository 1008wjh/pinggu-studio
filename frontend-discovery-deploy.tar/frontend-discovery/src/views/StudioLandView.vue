<template>
  <StudioAgentPage kind="land" title="土地评估" description="提取权属、规划、交易和收益材料，生成待复核初步报告。" />
</template>
<script setup lang="ts">
import StudioAgentPage from '@/components/studio/StudioAgentPage.vue'
</script>
